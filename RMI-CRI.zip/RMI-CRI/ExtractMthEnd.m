load dtd_mle_2000.mat
data1=firmDtd
date=data1(~isnan(data1(:,3)),2)
data1(isnan(data1(:,3)),2)
a=data1(data1(:,2)==20180531,:)
b=data1(data1(:,2)==20180430,:)
c=data1(data1(:,2)==20180328,:)
d=data1(data1(:,2)==20180227,:)
dtd_mle_2000_monthly=[a;b;c;d]
save("dtd_mle_2000_monthly.mat","dtd_mle_2000_monthly")