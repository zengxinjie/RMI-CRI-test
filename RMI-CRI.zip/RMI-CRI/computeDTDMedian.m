load firmSpecific.mat
load firmList.mat
Fin=firmList(firmList(:,2)==10008,1);
NonFin=firmList(firmList(:,2)~=10008,1);
data=firmSpecific;
%%%%%%%%%%%Descend Dimension %%%%%%%%%%%%%%
result=data(:,:,1);
for i=2:size(data,3)
    result=[result;data(:,:,i)];
end
data=result;
%%%%%%%%%%%%Generate DTD_median_Fin%%%%%%%%%%%
Fin_DTD=data(ismember(data(:,1),Fin),6);
median_Fin=median(Fin_DTD(~isnan(Fin_DTD),:));
DTD_median_Fin=nan(size(data,1),1);
DTD_median_Fin(ismember(data(:,1),Fin),:)=median_Fin;
data=[data,DTD_median_Fin];
%%%%%%%%%%%%%Generate DTD_median_NonFin%%%%%%%%%%%%
NonFin_DTD=data(ismember(data(:,1),NonFin),6);
median_NonFin=median(NonFin_DTD(~isnan(NonFin_DTD),:));
DTD_median_NonFin=nan(size(data,1),1);
DTD_median_NonFin(ismember(data(:,1),NonFin),:)=median_NonFin;
data=[data,DTD_median_NonFin];
%%%%%%%%%%%Ascend Dimension %%%%%%%%%%%%%%%
number=366;
begin=data(1:365,:);
for i=2:35
    begin=cat(3,begin,data(number:number+364,:));
    number=number+365;
end
data=begin;
varCol.DTD_median_Fin=13
varCol.DTD_median_NonFin=14