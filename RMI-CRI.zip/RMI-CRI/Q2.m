load pfinfo.mat
data=pfInfo.firmList
First_column=table(data(:,1))
writetable(First_column,"companylist.csv")

Financial=table(data(data(:,7)==10008,:))
writetable(Financial,"Companylist_Financial.csv")

Basic_Material=table(data(data(:,7)==10002,:))
writetable(Basic_Material,"Companylist_Basic_Material.csv")

Communications=table(data(data(:,7)==10003,:))
writetable(Communications,"Companylist_Communications.csv")

Consumer_cyclical=table(data(data(:,7)==10004,:))
writetable(Consumer_cyclical,"Consumer_cyclical.csv")

Consumer_noncyclical=table(data(data(:,7)==10005,:))
writetable(Consumer_noncyclical,"Consumer_noncyclical.csv")

Diversified=table(data(data(:,7)==10006,:))
writetable(Diversified,"Diversified.csv")

Energy=table(data(data(:,7)==10007,:))
writetable(Energy,"Energy.csv")

Industrial=table(data(data(:,7)==10011,:))
writetable(Industrial,"Industrial.csv")

Utilities=table(data(data(:,7)==10014,:))
writetable(Utilities,"Utilities.csv")


